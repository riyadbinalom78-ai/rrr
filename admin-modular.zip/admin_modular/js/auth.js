/* Admin authentication state.
   Client-side gate only: protects normal access flow, not server-side security.
*/
(function(window){
  'use strict';

  const KEY = 'admin_auth';
  const LEGACY_KEY = 'admin_unlocked';
  const ATTEMPTS_KEY = 'admin_attempts';
  const LOCK_KEY = 'admin_lock_until';

  function getSession(key){
    try { return sessionStorage.getItem(key); } catch(e) { return null; }
  }
  function setSession(key, value){
    try { sessionStorage.setItem(key, value); return true; } catch(e) { return false; }
  }
  function removeSession(key){
    try { sessionStorage.removeItem(key); } catch(e) {}
  }

  window.AdminAuth = {
    key: KEY,
    attemptsKey: ATTEMPTS_KEY,
    lockKey: LOCK_KEY,
    isAuthenticated: function(){ return getSession(KEY) === '1'; },
    setAuthenticated: function(){
      setSession(KEY, '1');
      removeSession(LEGACY_KEY);
      removeSession(ATTEMPTS_KEY);
      removeSession(LOCK_KEY);
    },
    logout: function(){
      removeSession(KEY);
      removeSession(LEGACY_KEY);
      removeSession(ATTEMPTS_KEY);
      removeSession(LOCK_KEY);
    },
    getAttempts: function(){ return Number(getSession(ATTEMPTS_KEY) || '0'); },
    getLockUntil: function(){ return Number(getSession(LOCK_KEY) || '0'); },
    registerFailure: function(){
      const next = this.getAttempts() + 1;
      setSession(ATTEMPTS_KEY, String(next));
      if(next >= 5) setSession(LOCK_KEY, String(Date.now() + 30000));
      return next;
    }
  };
})(window);

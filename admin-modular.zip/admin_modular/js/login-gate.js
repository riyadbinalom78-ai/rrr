/* Truck-style login gate.
   Loaded by admin.html only. No separate login HTML file exists.
*/
(function(window, document){
  'use strict';

  const HASH = '3eac7d60d04a80ec88c731cc255ed96d0e3a5d681ea1feb4666dfc7c60fb5640';
  const SALT = ':truck-gate-v1';
  const gate = document.getElementById('loginGate');

  function esc(value){
    return String(value).replace(/[&<>"']/g, function(ch){
      return ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'})[ch];
    });
  }

  function render(){
    gate.innerHTML = `
      <div class="login-scene">
        <div class="login-stars"></div>
        <div class="login-moon" aria-hidden="true"></div>
        <div class="login-hill back" aria-hidden="true"></div>
        <div class="login-hill" aria-hidden="true"></div>
        <div class="login-skyline" aria-hidden="true"></div>
        <div class="login-road" aria-hidden="true"></div>
        <div class="login-truck-wrap">
          <div class="login-truck-stage" id="loginTruckStage">
            <div class="login-truck" aria-hidden="true">
              <div class="login-cargo"><div class="login-cargo-label"><span>R</span> ADMIN ACCESS</div></div>
              <div class="login-cab"><div class="login-window"></div><div class="login-headlight"></div><div class="login-bumper"></div></div>
              <div class="login-wheel back"></div>
              <div class="login-wheel front"></div>
            </div>
            <form class="login-form-card" id="truckLoginForm" autocomplete="on">
              <h1>Admin Login</h1>
              <p>Authenticate to open the control panel.</p>
              <div class="login-field"><label for="truckUser">Username</label><input id="truckUser" name="username" autocomplete="username" autocapitalize="none" spellcheck="false" required></div>
              <div class="login-field"><label for="truckPass">Password</label><input id="truckPass" name="password" type="password" autocomplete="current-password" required></div>
              <button class="login-submit" id="truckGo" type="submit">Enter Admin Panel</button>
              <div class="login-msg" id="truckMsg" role="alert" aria-live="polite"></div>
            </form>
          </div>
        </div>
      </div>`;

    const form = document.getElementById('truckLoginForm');
    const user = document.getElementById('truckUser');
    const pass = document.getElementById('truckPass');
    const btn = document.getElementById('truckGo');
    const msg = document.getElementById('truckMsg');

    if(window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches){
      gate.classList.add('login-reduced');
    }

    form.addEventListener('submit', async function(event){
      event.preventDefault();
      await attempt(user.value, pass.value, btn, msg);
    });

    if(AdminAuth.isAuthenticated()){
      gate.classList.remove('is-visible');
    }else{
      gate.classList.add('is-visible');
      setTimeout(function(){ user.focus(); }, 50);
    }
  }

  async function sha256(text){
    if(!window.crypto || !crypto.subtle) throw new Error('Web Crypto API is unavailable in this browser.');
    const data = new TextEncoder().encode(text);
    const digest = await crypto.subtle.digest('SHA-256', data);
    return Array.from(new Uint8Array(digest)).map(function(b){ return b.toString(16).padStart(2,'0'); }).join('');
  }

  function lockRemaining(){
    return Math.max(0, Math.ceil((AdminAuth.getLockUntil() - Date.now()) / 1000));
  }

  async function attempt(username, password, btn, msg){
    const user = username.trim().toLowerCase();
    if(!user || !password){
      msg.textContent = 'Username and password are required.';
      msg.className = 'login-msg error';
      return;
    }

    const remaining = lockRemaining();
    if(remaining > 0){
      msg.textContent = 'Too many attempts. Try again in ' + remaining + 's.';
      msg.className = 'login-msg error';
      return;
    }

    btn.disabled = true;
    btn.textContent = 'Verifying…';
    msg.textContent = '';
    msg.className = 'login-msg';

    try{
      const hash = await sha256(user + ':' + password + SALT);
      if(hash === HASH){
        AdminAuth.setAuthenticated();
        msg.textContent = 'Access granted.';
        msg.className = 'login-msg ok';
        gate.classList.add('login-fade');
        setTimeout(function(){
          gate.classList.remove('is-visible', 'login-fade');
          if(window.startAdminApp) window.startAdminApp();
        }, 450);
      }else{
        const attempts = AdminAuth.registerFailure();
        const stage = document.getElementById('loginTruckStage');
        if(stage){
          gate.classList.remove('login-shake');
          void gate.offsetWidth;
          gate.classList.add('login-shake');
        }
        if(attempts >= 5){
          msg.textContent = 'Incorrect credentials. Login locked for 30 seconds.';
        }else{
          msg.textContent = 'Incorrect username or password.';
        }
        msg.className = 'login-msg error';
        pass.select();
      }
    }catch(error){
      msg.textContent = error.message || 'Could not verify credentials.';
      msg.className = 'login-msg error';
    }finally{
      btn.disabled = false;
      if(AdminAuth.isAuthenticated()) btn.textContent = 'Access granted';
      else btn.textContent = 'Enter Admin Panel';
    }
  }

  window.LoginGate = {
    show: function(){
      gate.classList.remove('login-fade');
      gate.classList.add('is-visible');
    },
    reset: function(){
      render();
    }
  };

  render();
})(window, document);

/* ══════════════════════════════════════
   ADMIN APP BOOTSTRAP
   Authentication is handled by js/auth.js + js/login-gate.js.
══════════════════════════════════════ */
function startAdminApp(){
  if(!window.AdminAuth || !AdminAuth.isAuthenticated()){
    if(window.LoginGate) LoginGate.show();
    return false;
  }
  const gate = document.getElementById('loginGate');
  if(gate) gate.classList.remove('is-visible');
  document.getElementById('app').classList.add('show');
  loadConnection();
  updateDashboard();
  goSection('dashboard');
  return true;
}

function lockPanel(){
  if(window.AdminAuth) AdminAuth.logout();
  else {
    try { sessionStorage.removeItem('admin_auth'); } catch(e) {}
    try { sessionStorage.removeItem('admin_unlocked'); } catch(e) {}
  }
  const gate = document.getElementById('loginGate');
  if(gate) gate.classList.add('is-visible');
  const app = document.getElementById('app');
  if(app) app.classList.remove('show');
  if(window.LoginGate) LoginGate.reset();
}

const SECTION_LABELS={dashboard:'Dashboard',profile:'My Profile',home:'Home',about:'About',skill:'Skill',blog:'Blog',lab:'Lab',contact:'Contact'};
const SECTION_LOADED={home:false,about:false,skill:false,blog:false,lab:false,contact:false};
function openDrawer(){
  document.getElementById('drawer').classList.add('open');
  document.getElementById('drawerOverlay').classList.add('open');
  document.getElementById('menuBtn').setAttribute('aria-expanded','true');
  document.body.classList.add('modal-open');
}
function closeDrawer(){
  document.getElementById('drawer').classList.remove('open');
  document.getElementById('drawerOverlay').classList.remove('open');
  const menu=document.getElementById('menuBtn');if(menu)menu.setAttribute('aria-expanded','false');
  if(!document.querySelector('.modal-overlay.show'))document.body.classList.remove('modal-open');
}

function goSection(name){const target=document.getElementById('sec-'+name);if(!target)return;document.querySelectorAll('.page-section').forEach(s=>s.classList.remove('active'));target.classList.add('active');document.querySelectorAll('.drawer-item').forEach(i=>i.classList.toggle('active',i.dataset.sec===name));document.getElementById('currentSectionTag').textContent=SECTION_LABELS[name]||name;closeDrawer();if(name==='dashboard'){updateDashboard();return}if(!localStorage.getItem('gh_token'))return;if(SECTION_LOADERS[name]&&!SECTION_LOADED[name])SECTION_LOADERS[name]().then(ok=>SECTION_LOADED[name]=(typeof ok==='boolean'?ok:true))}

/* ══════════════════════════════════════
   SHARED: CONNECTION + GITHUB HELPERS
══════════════════════════════════════ */
const API_BASE='https://api.github.com',GITHUB_API_VERSION='2022-11-28',FETCH_TIMEOUT_MS=20000;
const SECTION_LOADERS={home:loadHomeFields,about:loadAboutFields,skill:loadSkillFields,blog:blogLoadPostsList,lab:loadLabFields,contact:loadContactFields};
function getAuthHeaders(){const token=localStorage.getItem('gh_token');return{'Authorization':`Bearer ${token}`,'Accept':'application/vnd.github+json','X-GitHub-Api-Version':GITHUB_API_VERSION}}
function requireConnection(){if(!localStorage.getItem('gh_token')||!localStorage.getItem('gh_owner')||!localStorage.getItem('gh_repo'))throw new Error('Connect to GitHub from My Profile first.')}
async function githubFetch(path,options={}){const controller=new AbortController(),timer=setTimeout(()=>controller.abort(),FETCH_TIMEOUT_MS);try{const res=await fetch(`${API_BASE}${path}`,{...options,headers:{...getAuthHeaders(),...(options.headers||{})},signal:controller.signal,cache:'no-store'});if(!res.ok){const payload=await res.json().catch(()=>({}));const remaining=res.headers.get('X-RateLimit-Remaining');throw new Error((payload.message||`GitHub API error ${res.status}`)+(remaining==='0'?' GitHub API rate limit is exhausted.':''))}return res.status===204?null:res.json()}catch(e){if(e.name==='AbortError')throw new Error('Request timed out. Check your connection and try again.');throw e}finally{clearTimeout(timer)}}
function utf8ToBase64(text){const bytes=new TextEncoder().encode(String(text));let binary='';for(let i=0;i<bytes.length;i+=0x8000)binary+=String.fromCharCode(...bytes.subarray(i,i+0x8000));return btoa(binary)}
function base64ToUtf8(base64){const binary=atob(String(base64));const bytes=new Uint8Array(binary.length);for(let i=0;i<binary.length;i++)bytes[i]=binary.charCodeAt(i);return new TextDecoder().decode(bytes)}
function clearStoredConnection(){localStorage.removeItem('gh_token');localStorage.removeItem('gh_owner');localStorage.removeItem('gh_repo');Object.keys(SECTION_LOADED).forEach(k=>SECTION_LOADED[k]=false)}
function updateTokenMeta(){const el=document.getElementById('tokenMeta'),token=localStorage.getItem('gh_token');if(!token){el.textContent='No token saved in this browser.';return}el.textContent=`Saved locally · ${token.slice(0,4)}••••${token.slice(-4)}`}
function clearConnection(){clearStoredConnection();document.getElementById('token').value='';updateTokenMeta();setConnected(false);updateDashboard();showAlert('connStatus','<i class="fa-solid fa-circle-check"></i> GitHub connection removed from this browser.','alert-ok')}
function updateDashboard(){const token=localStorage.getItem('gh_token'),owner=localStorage.getItem('gh_owner'),repo=localStorage.getItem('gh_repo'),live=!!(token&&owner&&repo);document.getElementById('dashConnection').textContent=live?'Ready':'Offline';document.getElementById('dashStatusText').textContent=live?'Connected':'Offline';document.getElementById('dashOwner').textContent=owner||'—';document.getElementById('dashRepoName').textContent=repo||'—';document.getElementById('dashRepo').textContent=repo||'—';document.getElementById('profileStatus').textContent=live?'Connected':'Not connected';document.getElementById('profileStatus').classList.toggle('live',live);updateTokenMeta()}
async function refreshDashboard(){updateDashboard();if(!localStorage.getItem('gh_token'))return;const checked=document.getElementById('dashLastChecked');checked.textContent='Checking…';try{const owner=localStorage.getItem('gh_owner'),repo=localStorage.getItem('gh_repo'),info=await githubFetch(`/repos/${encodeURIComponent(owner)}/${encodeURIComponent(repo)}`);setConnected(true);document.getElementById('dashStatusText').textContent='Connected';document.getElementById('dashConnection').textContent='Live';document.getElementById('dashOwner').textContent=owner||'—';document.getElementById('dashRepoName').textContent=repo||'—';document.getElementById('dashRepo').textContent=repo||'—';checked.textContent=new Date().toLocaleTimeString([],{hour:'numeric',minute:'2-digit'});document.getElementById('profileStatus').textContent=info.permissions?.push?'Connected · Write':'Connected';document.getElementById('profileStatus').classList.add('live')}catch(e){setConnected(false);document.getElementById('dashStatusText').textContent='Offline';document.getElementById('dashConnection').textContent='Offline';checked.textContent='Check failed'}}


function toggleTokenVisibility(){
  const t = document.getElementById('token');
  const icon = document.getElementById('eyeIcon');
  if(t.type === 'password'){ t.type = 'text'; icon.className = 'fa-solid fa-eye-slash'; }
  else { t.type = 'password'; icon.className = 'fa-solid fa-eye'; }
}

function loadConnection(){const token=localStorage.getItem('gh_token'),owner=localStorage.getItem('gh_owner'),repo=localStorage.getItem('gh_repo');if(token)document.getElementById('token').value=token;if(owner)document.getElementById('owner').value=owner;if(repo)document.getElementById('repo').value=repo;setConnected(!!(token&&owner&&repo));updateTokenMeta();updateDashboard()}


function setConnected(on){document.getElementById('connPill').classList.toggle('live',on);document.getElementById('connLabel').textContent=on?'Connected':'Offline';const status=document.getElementById('profileStatus');if(status){status.textContent=on?'Connected':'Not connected';status.classList.toggle('live',on)}}


function showAlert(id,msg,type){const el=document.getElementById(id);if(!el)return;el.innerHTML=msg;el.className='alert show '+type}
function showErrorAlert(id,msg){showAlert(id,`<i class="fa-solid fa-circle-xmark"></i> ${escapeHtml(String(msg||'Something went wrong.'))}`,'alert-bad')}


async function saveConnection(){
  const token=document.getElementById('token').value.trim(),owner=document.getElementById('owner').value.trim(),repo=document.getElementById('repo').value.trim();
  if(!token||!owner||!repo){showAlert('connStatus','<i class="fa-solid fa-triangle-exclamation"></i> Token, owner and repository are required','alert-bad');return false}
  const btn=document.getElementById('connectBtn');btn.disabled=true;showAlert('connStatus','<i class="fa-solid fa-spinner fa-spin"></i> Verifying repository and write access...','alert-load');
  try{
    const controller=new AbortController(),timer=setTimeout(()=>controller.abort(),FETCH_TIMEOUT_MS);
    let res;
    try{
      res=await fetch(`${API_BASE}/repos/${encodeURIComponent(owner)}/${encodeURIComponent(repo)}`,{headers:{'Authorization':`Bearer ${token}`,'Accept':'application/vnd.github+json','X-GitHub-Api-Version':GITHUB_API_VERSION},signal:controller.signal,cache:'no-store'})
    }finally{clearTimeout(timer)}
    if(!res.ok){const payload=await res.json().catch(()=>({}));throw new Error(payload.message||`GitHub API error ${res.status}`)}
    const info=await res.json();
    if(!(info.permissions&&info.permissions.push))throw new Error('Repository is accessible, but this token does not have write permission.');
    localStorage.setItem('gh_token',token);localStorage.setItem('gh_owner',owner);localStorage.setItem('gh_repo',repo);setConnected(true);updateDashboard();
    showAlert('connStatus','<i class="fa-solid fa-circle-check"></i> Connected and write access verified.','alert-ok');Object.keys(SECTION_LOADED).forEach(k=>SECTION_LOADED[k]=false);return true
  }catch(e){clearStoredConnection();setConnected(false);updateDashboard();showErrorAlert('connStatus','Connection failed — '+e.message);return false}
  finally{btn.disabled=false}
}



async function getFile(path){requireConnection();const owner=localStorage.getItem('gh_owner'),repo=localStorage.getItem('gh_repo'),data=await githubFetch(`/repos/${encodeURIComponent(owner)}/${encodeURIComponent(repo)}/contents/${path}`);if(Array.isArray(data))throw new Error(`"${path}" is a directory, not a file.`);return{sha:data.sha,content:base64ToUtf8(String(data.content||'').replace(/\s/g,'')),url:data.html_url||''}}


async function putFile(path,contentStr,sha,message){requireConnection();const owner=localStorage.getItem('gh_owner'),repo=localStorage.getItem('gh_repo'),body={message:String(message||'Update file'),content:utf8ToBase64(contentStr)};if(sha)body.sha=sha;return githubFetch(`/repos/${encodeURIComponent(owner)}/${encodeURIComponent(repo)}/contents/${path}`,{method:'PUT',body:JSON.stringify(body)})}


async function putBinaryFile(path,base64Content,sha,message){requireConnection();const owner=localStorage.getItem('gh_owner'),repo=localStorage.getItem('gh_repo'),body={message:String(message||'Update binary file'),content:base64Content};if(sha)body.sha=sha;return githubFetch(`/repos/${encodeURIComponent(owner)}/${encodeURIComponent(repo)}/contents/${path}`,{method:'PUT',body:JSON.stringify(body)})}


function escapeHtml(str){
  const div = document.createElement('div');
  div.textContent = str;
  return div.innerHTML;
}

function readFileAsBase64(file){return new Promise((resolve,reject)=>{if(!file)return reject(new Error('No file selected.'));const reader=new FileReader();reader.onload=()=>resolve(String(reader.result).split(',')[1]||'');reader.onerror=()=>reject(new Error('Could not read the file.'));reader.readAsDataURL(file)})}


/* Marker helpers shared by Home / About / Contact (simple text fields) */
function htmlToText(html){
  let s = html.trim();
  s = s.replace(/<br\s*\/?>/gi, '\n');
  s = s.replace(/<strong[^>]*>(.*?)<\/strong>/gi, '**$1**');
  const div = document.createElement('div');
  div.innerHTML = s;
  return (div.textContent || '').trim();
}
function validateUrl(value,{allowRelative=false}={}){const v=String(value||'').trim();if(!v)return true;if(allowRelative&&(/^\/(?!\/)/.test(v)||/^[\w.-]+\//.test(v)))return true;try{const u=new URL(v);return u.protocol==='http:'||u.protocol==='https:'}catch{return false}}
function normalizeYoutubeUrl(value){const v=String(value||'').trim();if(!v)return '';if(!extractYouTubeId(v))throw new Error('Enter a valid YouTube URL.');return v}
function textToHtml(raw){
  let escaped = escapeHtml(raw.trim());
  escaped = escaped.replace(/\*\*(.+?)\*\*/g, '<strong>$1</strong>');
  escaped = escaped.replace(/\n/g, '<br>');
  return escaped;
}

/* ══════════════════════════════════════
   PHOTO UPLOAD (Home / About / Skill — fixed filenames)
══════════════════════════════════════ */
const pendingPhotos = {};

/* Resize + re-encode any photo (including large or unusual formats) as a
   compact JPEG before upload — avoids upload failures and keeps the repo small. */
function compressImage(file,maxDim=1400,quality=.82){return new Promise((resolve,reject)=>{if(!file)return reject(new Error('Choose an image first.'));if(!file.type.startsWith('image/'))return reject(new Error('Only image files are supported.'));if(file.size>12*1024*1024)return reject(new Error('Image is too large. Keep it under 12MB.'));const reader=new FileReader();reader.onerror=()=>reject(new Error('Could not read that image.'));reader.onload=e=>{const img=new Image();img.onerror=()=>reject(new Error('That file could not be read as an image.'));img.onload=()=>{let{width,height}=img;if(!width||!height)return reject(new Error('Invalid image dimensions.'));if(width>maxDim||height>maxDim){if(width>height){height=Math.round(height*(maxDim/width));width=maxDim}else{width=Math.round(width*(maxDim/height));height=maxDim}}const canvas=document.createElement('canvas');canvas.width=width;canvas.height=height;const ctx=canvas.getContext('2d',{alpha:false});if(!ctx)return reject(new Error('Could not process this image.'));ctx.drawImage(img,0,0,width,height);canvas.toBlob(blob=>blob?resolve(blob):reject(new Error('Could not compress this image.')),'image/jpeg',quality)};img.src=e.target.result};reader.readAsDataURL(file)})}


async function previewPhoto(event, wrapId){
  const file = event.target.files[0];
  if(!file) return;
  const inputId = event.target.id;
  const statusId = wrapId.replace('-preview','') === 'home-photo' ? 'homePhotoStatus' : wrapId.replace('-preview','') === 'about-photo' ? 'aboutPhotoStatus' : 'skillPhotoStatus';
  try {
    const compressed = await compressImage(file);
    pendingPhotos[inputId] = compressed;
    const reader = new FileReader();
    reader.onload = e => {
      const wrap = document.getElementById(wrapId);
      wrap.style.display = 'flex';
      wrap.querySelector('img').src = e.target.result;
    };
    reader.readAsDataURL(compressed);
  } catch(err){
    showAlert(statusId, '<i class="fa-solid fa-circle-xmark"></i> ' + err.message, 'alert-bad');
  }
}

async function uploadFixedPhoto(inputId,filename,statusId){const file=pendingPhotos[inputId];if(!file){showAlert(statusId,'<i class="fa-solid fa-triangle-exclamation"></i> Choose a photo first','alert-bad');return false}if(!localStorage.getItem('gh_token')){showAlert(statusId,'<i class="fa-solid fa-triangle-exclamation"></i> Connect in My Profile first','alert-bad');return false}showAlert(statusId,'<i class="fa-solid fa-spinner fa-spin"></i> Uploading...','alert-load');try{const existing=await getFile(filename),b64=await readFileAsBase64(file);await putBinaryFile(filename,b64,existing?existing.sha:null,`Update photo: ${filename}`);pendingPhotos[inputId]=null;document.getElementById(inputId).value='';showAlert(statusId,'<i class="fa-solid fa-circle-check"></i> Photo updated.','alert-ok');return true}catch(e){showErrorAlert(statusId,'Upload failed — '+e.message);return false}}


/* ══════════════════════════════════════
   HOME (index.html)
══════════════════════════════════════ */
async function loadHomeFields(){showAlert('homeStatus','<i class="fa-solid fa-spinner fa-spin"></i> Loading...','alert-load');try{const file=await getFile('index.html');if(!file)throw new Error('index.html not found');document.querySelectorAll('.fld-home').forEach(el=>{const key=el.dataset.key,s=file.content.indexOf(`<!-- EDIT:${key}:START -->`),e=file.content.indexOf(`<!-- EDIT:${key}:END -->`);if(s===-1||e===-1)return;el.value=htmlToText(file.content.slice(s+`<!-- EDIT:${key}:START -->`.length,e))});showAlert('homeStatus','<i class="fa-solid fa-circle-check"></i> Loaded.','alert-ok');return true}catch(e){showErrorAlert('homeStatus',e.message);return false}}


async function saveHomeFields(){
  const btn = document.getElementById('homeSaveBtn');
  btn.disabled = true;
  showAlert('homeStatus','<i class="fa-solid fa-spinner fa-spin"></i> Saving...','alert-load');
  try {
    const file = await getFile('index.html');
    if(!file) throw new Error('index.html not found');
    let content = file.content;
    document.querySelectorAll('.fld-home').forEach(el => {
      const key = el.dataset.key;
      const startTag = `<!-- EDIT:${key}:START -->`, endTag = `<!-- EDIT:${key}:END -->`;
      const s = content.indexOf(startTag), e = content.indexOf(endTag);
      if(s === -1 || e === -1) return;
      content = content.slice(0, s + startTag.length) + textToHtml(el.value) + content.slice(e);
    });
    await putFile('index.html', content, file.sha, 'Update homepage via admin panel');
    showAlert('homeStatus','<i class="fa-solid fa-circle-check"></i> Saved! Live in a minute.','alert-ok');
  } catch(e){ showErrorAlert('homeStatus', e.message); }
  finally { btn.disabled = false; }
}

/* ══════════════════════════════════════
   ABOUT (about.html)
══════════════════════════════════════ */
async function loadAboutFields(){showAlert('aboutStatus','<i class="fa-solid fa-spinner fa-spin"></i> Loading...','alert-load');try{const file=await getFile('about.html');if(!file)throw new Error('about.html not found');document.querySelectorAll('.fld-about').forEach(el=>{const key=el.dataset.key,s=file.content.indexOf(`<!-- EDIT:${key}:START -->`),e=file.content.indexOf(`<!-- EDIT:${key}:END -->`);if(s===-1||e===-1)return;el.value=htmlToText(file.content.slice(s+`<!-- EDIT:${key}:START -->`.length,e))});showAlert('aboutStatus','<i class="fa-solid fa-circle-check"></i> Loaded.','alert-ok');return true}catch(e){showErrorAlert('aboutStatus',e.message);return false}}


async function saveAboutFields(){
  const btn = document.getElementById('aboutSaveBtn');
  btn.disabled = true;
  showAlert('aboutStatus','<i class="fa-solid fa-spinner fa-spin"></i> Saving...','alert-load');
  try {
    const file = await getFile('about.html');
    if(!file) throw new Error('about.html not found');
    let content = file.content;
    document.querySelectorAll('.fld-about').forEach(el => {
      const key = el.dataset.key;
      const startTag = `<!-- EDIT:${key}:START -->`, endTag = `<!-- EDIT:${key}:END -->`;
      const s = content.indexOf(startTag), e = content.indexOf(endTag);
      if(s === -1 || e === -1) return;
      content = content.slice(0, s + startTag.length) + textToHtml(el.value) + content.slice(e);
    });
    await putFile('about.html', content, file.sha, 'Update about page via admin panel');
    showAlert('aboutStatus','<i class="fa-solid fa-circle-check"></i> Saved! Live in a minute.','alert-ok');
  } catch(e){ showErrorAlert('aboutStatus', e.message); }
  finally { btn.disabled = false; }
}

/* ══════════════════════════════════════
   SKILL (skills.html) — dynamic groups of skill items
══════════════════════════════════════ */
const SKILL_GROUP_KEYS = ['group1','group2','group3','group4'];
const SKILL_GROUP_TITLES = { group1:'Core Academic & Thinking', group2:'Communication & Community', group3:'Technical & Practical', group4:'Languages' };
let skillGroupsData = {};
let workItemsData = [];
let skillIdCounter = 0;

function renderSkillGroups(){
  const host = document.getElementById('skillGroupsHost');
  host.innerHTML = '';
  SKILL_GROUP_KEYS.forEach(gKey => {
    const items = skillGroupsData[gKey] || [];
    const groupEl = document.createElement('details');
    groupEl.className = 'mini';
    groupEl.open = true;
    groupEl.innerHTML = `
      <summary>
        <input type="text" class="fld-skill-group-label" data-group="${gKey}" value="${escapeHtml(SKILL_GROUP_TITLES[gKey])}" style="border:none;background:none;font-weight:600;font-size:13px;padding:0;width:auto;flex:1;" onclick="event.stopPropagation()">
        <i class="fa-solid fa-chevron-down chev"></i>
      </summary>
      <div class="mini-body">
        <div id="items-${gKey}"></div>
        <button type="button" class="btn btn-outline btn-sm" style="margin-top:6px;" onclick="addSkillItem('${gKey}')"><i class="fa-solid fa-plus"></i> Add Skill</button>
      </div>`;
    host.appendChild(groupEl);
    const itemsHost = groupEl.querySelector(`#items-${gKey}`);
    if(!items.length){ itemsHost.innerHTML = '<div class="item-empty">No skills yet.</div>'; }
    items.forEach(item => itemsHost.appendChild(buildSkillItemRow(gKey, item)));
  });
}

function buildSkillItemRow(gKey, item){
  const row = document.createElement('div');
  row.className = 'item-row';
  row.dataset.id = item.id;
  const showDesc = gKey !== 'group4';
  row.innerHTML = `
    <div class="grid2">
      <input type="text" class="sk-name" placeholder="Skill name" value="${escapeHtml(item.name||'')}">
      <input type="text" class="sk-level" placeholder="Level label" value="${escapeHtml(item.level||'')}">
    </div>
    <div class="row-inline" style="margin-top:8px;">
      <input type="text" class="sk-pct" placeholder="% (e.g. 82)" value="${escapeHtml(item.pct||'')}" style="max-width:110px;">
      ${showDesc ? `<input type="text" class="sk-desc" placeholder="Short description" value="${escapeHtml(item.desc||'')}">` : ''}
      <button type="button" class="btn-icon danger" onclick="removeSkillItem('${gKey}','${item.id}')" title="Remove"><i class="fa-solid fa-trash"></i></button>
    </div>`;
  return row;
}

function addSkillItem(gKey){
  if(!skillGroupsData[gKey]) skillGroupsData[gKey] = [];
  skillGroupsData[gKey].push({ id:'sk'+(skillIdCounter++), name:'', level:'', pct:'70', desc:'' });
  renderSkillGroups();
}
function removeSkillItem(gKey, id){
  skillGroupsData[gKey] = (skillGroupsData[gKey]||[]).filter(i => i.id !== id);
  renderSkillGroups();
}

function renderWorkItems(){
  const host = document.getElementById('workListHost');
  host.innerHTML = '';
  if(!workItemsData.length){ host.innerHTML = '<div class="item-empty">No lines yet.</div>'; }
  workItemsData.forEach(item => {
    const row = document.createElement('div');
    row.className = 'row-inline';
    row.style.marginTop = '6px';
    row.innerHTML = `<input type="text" class="work-text" value="${escapeHtml(item.text)}" data-id="${item.id}"><button type="button" class="btn-icon danger" onclick="removeWorkItem('${item.id}')"><i class="fa-solid fa-trash"></i></button>`;
    host.appendChild(row);
  });
}
function addWorkItem(){ workItemsData.push({ id:'w'+(skillIdCounter++), text:'' }); renderWorkItems(); }
function removeWorkItem(id){ workItemsData = workItemsData.filter(i => i.id !== id); renderWorkItems(); }

function collectSkillGroupsFromDOM(){
  SKILL_GROUP_KEYS.forEach(gKey => {
    const host = document.getElementById(`items-${gKey}`);
    if(!host) return;
    const rows = Array.from(host.querySelectorAll('.item-row'));
    skillGroupsData[gKey] = rows.map(row => ({
      id: row.dataset.id,
      name: row.querySelector('.sk-name').value.trim(),
      level: row.querySelector('.sk-level').value.trim(),
      pct: row.querySelector('.sk-pct').value.trim() || '70',
      desc: row.querySelector('.sk-desc') ? row.querySelector('.sk-desc').value.trim() : ''
    }));
  });
  workItemsData = Array.from(document.querySelectorAll('.work-text')).map(inp => ({ id: inp.dataset.id, text: inp.value.trim() })).filter(w => w.text);
}

async function loadSkillFields(){showAlert('skillStatus','<i class="fa-solid fa-spinner fa-spin"></i> Loading...','alert-load');try{const file=await getFile('skills.html');if(!file)throw new Error('skills.html not found');document.querySelectorAll('.fld-skill-page').forEach(el=>{const key=el.dataset.key,s=file.content.indexOf(`<!-- EDIT:${key}:START -->`),e=file.content.indexOf(`<!-- EDIT:${key}:END -->`);if(s===-1||e===-1)return;el.value=htmlToText(file.content.slice(s+`<!-- EDIT:${key}:START -->`.length,e))});SKILL_GROUP_KEYS.forEach(gKey=>{const labelS=file.content.indexOf(`<!-- EDIT:${gKey}-label:START -->`),labelE=file.content.indexOf(`<!-- EDIT:${gKey}-label:END -->`);if(labelS!==-1&&labelE!==-1)SKILL_GROUP_TITLES[gKey]=htmlToText(file.content.slice(labelS+`<!-- EDIT:${gKey}-label:START -->`.length,labelE));const items=[],re=new RegExp(`<!-- SKITEM:(${gKey}-[\\w-]+):START -->([\\s\\S]*?)<!-- SKITEM:\\1:END -->`,'g');let m;while((m=re.exec(file.content))!==null){const parser=new DOMParser(),doc=parser.parseFromString(`<div>${m[2]}</div>`,'text/html'),nameEl=doc.querySelector('.skill-name'),levelEl=doc.querySelector('.skill-level'),barEl=doc.querySelector('.skill-bar-fill'),descEl=doc.querySelector('.skill-desc');items.push({id:m[1],name:nameEl?nameEl.textContent.trim():'',level:levelEl?levelEl.textContent.trim():'',pct:barEl?(barEl.getAttribute('data-w')||'70'):'70',desc:descEl?descEl.textContent.trim():''})}skillGroupsData[gKey]=items});workItemsData=[];const workRe=/<!-- WORKITEM:([\w-]+):START -->([\s\S]*?)<!-- WORKITEM:\1:END -->/g;let wm;while((wm=workRe.exec(file.content))!==null){const parser=new DOMParser(),doc=parser.parseFromString(`<div>${wm[2]}</div>`,'text/html');workItemsData.push({id:wm[1],text:(doc.textContent||'').trim()})}renderSkillGroups();renderWorkItems();showAlert('skillStatus','<i class="fa-solid fa-circle-check"></i> Loaded.','alert-ok');return true}catch(e){showErrorAlert('skillStatus',e.message);return false}}


async function saveSkillFields(){
  collectSkillGroupsFromDOM();
  const btn = document.getElementById('skillSaveBtn');
  btn.disabled = true;
  showAlert('skillStatus','<i class="fa-solid fa-spinner fa-spin"></i> Saving...','alert-load');
  try {
    const file = await getFile('skills.html');
    if(!file) throw new Error('skills.html not found');
    let content = file.content;

    document.querySelectorAll('.fld-skill-page').forEach(el => {
      const key = el.dataset.key;
      const startTag = `<!-- EDIT:${key}:START -->`, endTag = `<!-- EDIT:${key}:END -->`;
      const s = content.indexOf(startTag), e = content.indexOf(endTag);
      if(s === -1 || e === -1) return;
      content = content.slice(0, s + startTag.length) + textToHtml(el.value) + content.slice(e);
    });

    SKILL_GROUP_KEYS.forEach(gKey => {
      const labelInput = document.querySelector(`.fld-skill-group-label[data-group="${gKey}"]`);
      const labelVal = labelInput ? labelInput.value.trim() : SKILL_GROUP_TITLES[gKey];
      const labelStart = `<!-- EDIT:${gKey}-label:START -->`, labelEnd = `<!-- EDIT:${gKey}-label:END -->`;
      const lS = content.indexOf(labelStart), lE = content.indexOf(labelEnd);
      if(lS !== -1 && lE !== -1){
        content = content.slice(0, lS + labelStart.length) + escapeHtml(labelVal) + content.slice(lE);
      }

      const insertMark = `<!-- GROUP:${gKey}:INSERT -->`;
      const existingRe = new RegExp(`<!-- SKITEM:${gKey}-[\\w-]+:START -->[\\s\\S]*?<!-- SKITEM:${gKey}-[\\w-]+:END -->\\s*`, 'g');
      content = content.replace(existingRe, '');

      const items = skillGroupsData[gKey] || [];
      const showDesc = gKey !== 'group4';
      const blocks = items.map(item => {
        const descHtml = showDesc && item.desc ? `\n          <div class="skill-desc">${escapeHtml(item.desc)}</div>` : '';
        return `<!-- SKITEM:${item.id}:START -->
        <div class="skill-item">
          <div class="skill-top">
            <span class="skill-name">${escapeHtml(item.name)}</span>
            <span class="skill-level">${escapeHtml(item.level)}</span>
          </div>
          <div class="skill-bar"><div class="skill-bar-fill" data-w="${escapeHtml(item.pct)}"></div></div>${descHtml}
        </div>
        <!-- SKITEM:${item.id}:END -->`;
      }).join('\n        ');

      const iM = content.indexOf(insertMark);
      if(iM !== -1){
        content = content.slice(0, iM + insertMark.length) + '\n        ' + blocks + content.slice(iM + insertMark.length);
      }
    });

    const workInsertMark = '<!-- WORK:INSERT -->';
    const existingWorkRe = /<!-- WORKITEM:[\w-]+:START -->[\s\S]*?<!-- WORKITEM:[\w-]+:END -->\s*/g;
    content = content.replace(existingWorkRe, '');
    const workBlocks = workItemsData.map(item => `<!-- WORKITEM:${item.id}:START --><li>${escapeHtml(item.text)}</li><!-- WORKITEM:${item.id}:END -->`).join('\n          ');
    const wIM = content.indexOf(workInsertMark);
    if(wIM !== -1){
      content = content.slice(0, wIM + workInsertMark.length) + '\n          ' + workBlocks + content.slice(wIM + workInsertMark.length);
    }

    await putFile('skills.html', content, file.sha, 'Update skills page via admin panel');
    showAlert('skillStatus','<i class="fa-solid fa-circle-check"></i> Saved! Live in a minute.','alert-ok');
  } catch(e){ showErrorAlert('skillStatus', e.message); }
  finally { btn.disabled = false; }
}

/* ══════════════════════════════════════
   LAB (lab.html)
══════════════════════════════════════ */
let labSitesData = [];
let comingSoonTags = [];
let editingSiteId = null;

function renderLabSites(){
  const host = document.getElementById('labSitesHost');
  if(!labSitesData.length){ host.innerHTML = '<div class="item-empty">No sites yet.</div>'; return; }
  host.innerHTML = labSitesData.map(site => `
    <div class="item-row">
      <div class="item-row-head">
        <div class="item-row-title">${escapeHtml(site.emoji||'')} ${escapeHtml(site.title||'(untitled)')}</div>
        <div class="item-row-actions">
          <button class="btn-icon" onclick="labOpenSiteForm('${site.id}')" title="Edit"><i class="fa-solid fa-pen"></i></button>
          <button class="btn-icon danger" onclick="labRemoveSite('${site.id}')" title="Delete"><i class="fa-solid fa-trash"></i></button>
        </div>
      </div>
      <div style="font-size:12px;color:var(--dim);">${escapeHtml(site.tag||'')}</div>
    </div>`).join('');
}

function labOpenSiteForm(id){
  editingSiteId = id;
  const site = id ? labSitesData.find(s => s.id === id) : { emoji:'', tag:'', title:'', desc:'', url:'' };
  document.getElementById('siteModalTitle').textContent = id ? 'Edit Site' : 'Add Site';
  document.getElementById('siteEmoji').value = site.emoji || '';
  document.getElementById('siteTag').value = site.tag || '';
  document.getElementById('siteTitle').value = site.title || '';
  document.getElementById('siteDesc').value = site.desc || '';
  document.getElementById('siteUrl').value = site.url || '';
  document.getElementById('siteModal').classList.add('show');
}
function closeSiteModal(){ document.getElementById('siteModal').classList.remove('show'); editingSiteId = null; }

document.getElementById('siteModalSaveBtn').addEventListener('click',()=>{const data={emoji:document.getElementById('siteEmoji').value.trim(),tag:document.getElementById('siteTag').value.trim(),title:document.getElementById('siteTitle').value.trim(),desc:document.getElementById('siteDesc').value.trim(),url:document.getElementById('siteUrl').value.trim()},titleEl=document.getElementById('siteTitle'),urlEl=document.getElementById('siteUrl');titleEl.removeAttribute('aria-invalid');urlEl.removeAttribute('aria-invalid');if(!data.title){titleEl.setAttribute('aria-invalid','true');titleEl.focus();return}if(!validateUrl(data.url,{allowRelative:true})){urlEl.setAttribute('aria-invalid','true');urlEl.focus();return}if(editingSiteId){const idx=labSitesData.findIndex(s=>s.id===editingSiteId);if(idx!==-1)labSitesData[idx]={...labSitesData[idx],...data}}else labSitesData.push({id:'site'+Date.now(),...data});renderLabSites();closeSiteModal()});

function labRemoveSite(id){
  labSitesData = labSitesData.filter(s => s.id !== id);
  renderLabSites();
}

function renderComingSoonChips(){
  const host = document.getElementById('comingSoonChips');
  host.innerHTML = comingSoonTags.map((tag,i) => `<span class="chip">${escapeHtml(tag)}<button onclick="removeComingSoonChip(${i})">✕</button></span>`).join('');
}
function addComingSoonChip(){
  const input = document.getElementById('comingSoonInput');
  const val = input.value.trim();
  if(!val) return;
  comingSoonTags.push(val);
  input.value = '';
  renderComingSoonChips();
}
function removeComingSoonChip(i){ comingSoonTags.splice(i,1); renderComingSoonChips(); }

async function loadLabFields(){showAlert('labStatus','<i class="fa-solid fa-spinner fa-spin"></i> Loading...','alert-load');try{const file=await getFile('lab.html');if(!file)throw new Error('lab.html not found');document.querySelectorAll('.fld-lab').forEach(el=>{const key=el.dataset.key;if(key==='hisab-download'){const m=file.content.match(/id="hisab-download-link"[^>]*href="([^"]*)"/);if(m)el.value=m[1];return}const s=file.content.indexOf(`<!-- EDIT:${key}:START -->`),e=file.content.indexOf(`<!-- EDIT:${key}:END -->`);if(s===-1||e===-1)return;el.value=htmlToText(file.content.slice(s+`<!-- EDIT:${key}:START -->`.length,e))});for(const gk of ['game1','game2']){const m=file.content.match(new RegExp(`id="${gk}-play-link"[^>]*href="([^"]*)"`)),linkEl=document.querySelector(`.fld-lab[data-key="${gk}-link"]`);if(m&&linkEl)linkEl.value=m[1]}labSitesData=[];const siteRe=/<!-- SITE:([\w-]+):START -->([\s\S]*?)<!-- SITE:\1:END -->/g;let sm;while((sm=siteRe.exec(file.content))!==null){const parser=new DOMParser(),doc=parser.parseFromString(`<div>${sm[2]}</div>`,'text/html'),emojiEl=doc.querySelector('.sf-emoji, .sc-emoji'),tagEl=doc.querySelector('.sf-tag, .sc-tag'),titleEl=doc.querySelector('.sf-h, .sc-h'),descEl=doc.querySelector('.sf-p, .sc-p'),linkEl=doc.querySelector('a');labSitesData.push({id:sm[1],emoji:emojiEl?emojiEl.textContent.trim():'',tag:tagEl?tagEl.textContent.trim():'',title:titleEl?titleEl.textContent.trim():'',desc:descEl?descEl.textContent.trim():'',url:(linkEl&&validateUrl(linkEl.getAttribute('href'),{allowRelative:true}))?linkEl.getAttribute('href'):''})}renderLabSites();comingSoonTags=[];const csS=file.content.indexOf('<!-- EDIT:coming-soon:START -->'),csE=file.content.indexOf('<!-- EDIT:coming-soon:END -->');if(csS!==-1&&csE!==-1){const parser=new DOMParser(),doc=parser.parseFromString(`<div>${file.content.slice(csS+'<!-- EDIT:coming-soon:START -->'.length,csE)}</div>`,'text/html');comingSoonTags=Array.from(doc.querySelectorAll('.coming-pill')).map(p=>p.textContent.trim())}renderComingSoonChips();showAlert('labStatus','<i class="fa-solid fa-circle-check"></i> Loaded.','alert-ok');return true}catch(e){showErrorAlert('labStatus',e.message);return false}}


async function saveLabFields(){
  const btn = document.getElementById('labSaveBtn');
  btn.disabled = true;
  showAlert('labStatus','<i class="fa-solid fa-spinner fa-spin"></i> Saving...','alert-load');
  try {
    const file = await getFile('lab.html');
    if(!file) throw new Error('lab.html not found');
    let content = file.content;

    document.querySelectorAll('.fld-lab').forEach(el => {
      const key = el.dataset.key;
      if(key === 'hisab-download'){
        content = content.replace(/(id="hisab-download-link"[^>]*href=")[^"]*(")/, `$1${el.value.trim()}$2`);
        return;
      }
      if(key === 'game1-link' || key === 'game2-link'){
        const gk = key.split('-')[0];
        content = content.replace(new RegExp(`(id="${gk}-play-link"[^>]*href=")[^"]*(")`), `$1${el.value.trim()}$2`);
        return;
      }
      const startTag = `<!-- EDIT:${key}:START -->`, endTag = `<!-- EDIT:${key}:END -->`;
      const s = content.indexOf(startTag), e = content.indexOf(endTag);
      if(s === -1 || e === -1) return;
      content = content.slice(0, s + startTag.length) + textToHtml(el.value) + content.slice(e);
    });

    const siteInsertMark = '<!-- SITES:INSERT -->';
    const existingSiteRe = /<!-- SITE:[\w-]+:START -->[\s\S]*?<!-- SITE:[\w-]+:END -->\s*/g;
    content = content.replace(existingSiteRe, '');
    const siteBlocks = labSitesData.map(site => `<!-- SITE:${site.id}:START -->
      <a href="${escapeHtml(site.url)}" target="_blank" class="site-card reveal">
        <div class="sc-visual"><div class="sc-emoji">${site.emoji}</div></div>
        <div class="sc-body">
          <div class="sc-tag">${escapeHtml(site.tag)}</div>
          <div class="sc-h">${escapeHtml(site.title)}</div>
          <p class="sc-p">${escapeHtml(site.desc)}</p>
        </div>
      </a>
      <!-- SITE:${site.id}:END -->`).join('\n      ');
    const sIM = content.indexOf(siteInsertMark);
    if(sIM !== -1){
      content = content.slice(0, sIM + siteInsertMark.length) + '\n      ' + siteBlocks + content.slice(sIM + siteInsertMark.length);
    }

    const csStart = '<!-- EDIT:coming-soon:START -->', csEnd = '<!-- EDIT:coming-soon:END -->';
    const csS = content.indexOf(csStart), csE = content.indexOf(csEnd);
    if(csS !== -1 && csE !== -1){
      const pillsHtml = comingSoonTags.map(t => `<div class="coming-pill">${escapeHtml(t)}</div>`).join('\n      ');
      content = content.slice(0, csS + csStart.length) + '\n      ' + pillsHtml + '\n      ' + content.slice(csE);
    }

    await putFile('lab.html', content, file.sha, 'Update lab page via admin panel');
    showAlert('labStatus','<i class="fa-solid fa-circle-check"></i> Saved! Live in a minute.','alert-ok');
  } catch(e){ showErrorAlert('labStatus', e.message); }
  finally { btn.disabled = false; }
}

/* ══════════════════════════════════════
   CONTACT (contact.html + social.json)
══════════════════════════════════════ */
async function loadContactFields(){showAlert('contactStatus','<i class="fa-solid fa-spinner fa-spin"></i> Loading...','alert-load');try{const file=await getFile('contact.html');if(file)document.querySelectorAll('.fld-contact').forEach(el=>{const key=el.dataset.key,s=file.content.indexOf(`<!-- EDIT:${key}:START -->`),e=file.content.indexOf(`<!-- EDIT:${key}:END -->`);if(s===-1||e===-1)return;el.value=htmlToText(file.content.slice(s+`<!-- EDIT:${key}:START -->`.length,e))});const socialFile=await getFile('social.json');if(socialFile){const data=JSON.parse(socialFile.content);document.getElementById('social-fb').value=data.facebook||'';document.getElementById('social-x').value=data.x||'';document.getElementById('social-ig').value=data.instagram||'';document.getElementById('social-yt').value=data.youtube||''}showAlert('contactStatus','<i class="fa-solid fa-circle-check"></i> Loaded.','alert-ok');return true}catch(e){showErrorAlert('contactStatus',e.message);return false}}


async function saveContactFields(){
  const btn = document.getElementById('contactSaveBtn');
  btn.disabled = true;
  showAlert('contactStatus','<i class="fa-solid fa-spinner fa-spin"></i> Saving...','alert-load');
  try {
    const file = await getFile('contact.html');
    if(file){
      let content = file.content;
      document.querySelectorAll('.fld-contact').forEach(el => {
        const key = el.dataset.key;
        const startTag = `<!-- EDIT:${key}:START -->`, endTag = `<!-- EDIT:${key}:END -->`;
        const s = content.indexOf(startTag), e = content.indexOf(endTag);
        if(s === -1 || e === -1) return;
        content = content.slice(0, s + startTag.length) + textToHtml(el.value) + content.slice(e);
      });
      await putFile('contact.html', content, file.sha, 'Update contact page via admin panel');
    }

    const socialData = {
      facebook: document.getElementById('social-fb').value.trim(),
      x: document.getElementById('social-x').value.trim(),
      instagram: document.getElementById('social-ig').value.trim(),
      youtube: document.getElementById('social-yt').value.trim()
    };
    const existingSocial = await getFile('social.json');
    await putFile('social.json', JSON.stringify(socialData, null, 2), existingSocial ? existingSocial.sha : null, 'Update social links via admin panel');

    showAlert('contactStatus','<i class="fa-solid fa-circle-check"></i> Saved! Social links now live everywhere.','alert-ok');
  } catch(e){ showErrorAlert('contactStatus', e.message); }
  finally { btn.disabled = false; }
}

/* ══════════════════════════════════════
   BLOG (blog.html) — full CRUD, ported from the standalone blog admin
══════════════════════════════════════ */
const BLOG_INSERT_MARK = '<!-- ADMIN:INSERT-AFTER -->';
let blogCurrentLang = 'en';
let blogEditingId = null;
let blogEditingOriginalDateTime = null;
let blogSelectedImageFile = null;
let blogExistingImagePath = null;
let blogSelectedVideoFile = null;
let blogExistingVideoPath = null;
let blogVideoMode = 'yt';

function switchBlogTab(name){
  document.querySelectorAll('.subtab').forEach(t => t.classList.toggle('active', t.dataset.sub === name));
  document.querySelectorAll('.subpanel').forEach(p => p.classList.remove('active'));
  document.getElementById('blogtab-' + name).classList.add('active');
  if(name === 'posts') blogLoadPostsList();
}

function blogSetLang(lang){
  blogCurrentLang = lang;
  document.getElementById('blogLangEn').classList.toggle('active', lang === 'en');
  document.getElementById('blogLangBn').classList.toggle('active', lang === 'bn');
  blogUpdatePreview();
}

async function blogHandleImageSelect(e){
  const file = e.target.files[0];
  if(!file) return;
  try {
    const compressed = await compressImage(file);
    blogSelectedImageFile = compressed;
    blogExistingImagePath = null;
    const reader = new FileReader();
    reader.onload = ev => {
      document.getElementById('blogImagePreviewImg').src = ev.target.result;
      document.getElementById('blogImagePreviewWrap').style.display = 'flex';
      blogUpdatePreview();
    };
    reader.readAsDataURL(compressed);
  } catch(err){
    showAlert('blogPublishStatus', '<i class="fa-solid fa-circle-xmark"></i> ' + err.message, 'alert-bad');
  }
}
function blogClearImage(){
  blogSelectedImageFile = null; blogExistingImagePath = null;
  document.getElementById('blogImageFile').value = '';
  document.getElementById('blogImagePreviewWrap').style.display = 'none';
  blogUpdatePreview();
}
function blogSetVideoMode(mode){
  blogVideoMode = mode;
  document.getElementById('blogVidYt').classList.toggle('active', mode === 'yt');
  document.getElementById('blogVidUp').classList.toggle('active', mode === 'upload');
  document.getElementById('blogVideoYtWrap').style.display = mode === 'yt' ? 'block' : 'none';
  document.getElementById('blogVideoUpWrap').style.display = mode === 'upload' ? 'block' : 'none';
  blogUpdatePreview();
}
function blogHandleVideoSelect(e){const file=e.target.files[0];if(!file)return;if(!file.type.startsWith('video/')){showErrorAlert('blogPublishStatus','Choose a valid video file.');e.target.value='';return}if(file.size>20*1024*1024){showErrorAlert('blogPublishStatus','Video must be 20MB or smaller.');e.target.value='';return}blogSelectedVideoFile=file;document.getElementById('blogVideoFileName').textContent=`${file.name} (${(file.size/1024/1024).toFixed(1)} MB)`;document.getElementById('blogVideoPreviewWrap').style.display='flex';blogUpdatePreview()}

function blogClearVideo(){blogSelectedVideoFile=null;blogExistingVideoPath=null;document.getElementById('blogVideoFile').value='';document.getElementById('blogVideoPreviewWrap').style.display='none';document.getElementById('blogVideoFileName').textContent='';blogUpdatePreview()}

function extractYouTubeId(url){
  if(!url) return null;
  const m = url.match(/(?:youtu\.be\/|youtube\.com\/(?:watch\?v=|embed\/|shorts\/))([\w-]{11})/);
  return m ? m[1] : null;
}
function formatDateTime(d){
  const datePart = d.toLocaleDateString('en-US', { month:'short', day:'numeric', year:'numeric' });
  const timePart = d.toLocaleTimeString('en-US', { hour:'numeric', minute:'2-digit', hour12:true });
  return `${datePart} · ${timePart}`;
}

function blogBuildArticleBlock(id, title, tag, content, quote, lang, dateTimeStr, imagePath, videoPath, videoUrl){
  const h1Class = lang === 'bn' ? 'article-h1-bn' : 'article-h1';
  const paragraphs = content.split(/\n\s*\n/).map(p => p.trim()).filter(Boolean);
  const pHtml = paragraphs.map(p => `        <p class="article-p">${escapeHtml(p)}</p>`).join('\n\n');
  const quoteHtml = quote && quote.trim() ? `\n\n        <div class="article-quote">\n          <p>${escapeHtml(quote.trim())}</p>\n        </div>` : '';
  const finalDateTime = dateTimeStr || formatDateTime(new Date());
  let mediaHtml = '';
  if(imagePath) mediaHtml += `\n\n        <div class="article-image">\n          <img src="${escapeHtml(imagePath)}" alt="${escapeHtml(title)}">\n        </div>`;
  if(videoPath) mediaHtml += `\n\n        <div class="article-video">\n          <video controls src="${escapeHtml(videoPath)}"></video>\n        </div>`;
  else if(videoUrl){
    const ytId = extractYouTubeId(videoUrl);
    if(ytId) mediaHtml += `\n\n        <div class="article-video">\n          <iframe src="https://www.youtube.com/embed/${ytId}" title="video" allowfullscreen loading="lazy"></iframe>\n        </div>`;
  }
  return `<!-- POST:${id}:START -->
      <article class="article reveal visible">
        <div class="article-meta">
          <span class="article-tag">${escapeHtml(tag || 'Reflection')}</span>
          <span class="article-date">${escapeHtml(finalDateTime)}</span>
        </div>
        <h1 class="${h1Class}">${escapeHtml(title)}</h1>${mediaHtml}

${pHtml}${quoteHtml}
      </article>
<!-- POST:${id}:END -->
`;
}

function blogUpdatePreview(){const title=document.getElementById('blogTitle').value.trim(),tag=document.getElementById('blogTag').value.trim(),content=document.getElementById('blogContent').value.trim(),quote=document.getElementById('blogQuote').value.trim(),box=document.getElementById('blogPreviewBox'),hasImage=!!(blogSelectedImageFile||blogExistingImagePath),hasVideo=!!(blogSelectedVideoFile||blogExistingVideoPath||document.getElementById('blogVideoUrl').value.trim());if(!title&&!content&&!hasImage&&!hasVideo){box.innerHTML='<span style="color:var(--dim)">Start typing to preview...</span>';return}const paragraphs=content.split(/\n\s*\n/).map(p=>p.trim()).filter(Boolean);let html=`<div style="font-size:11px;color:var(--dim);margin-bottom:6px;">${escapeHtml(tag||'Reflection')} · ${formatDateTime(new Date())}</div>`;html+=`<div style="font-weight:800;font-size:15px;margin-bottom:8px;">${escapeHtml(title||'Title')}</div>`;const imageSrc=document.getElementById('blogImagePreviewImg').src;if(hasImage&&imageSrc)html+=`<img src="${escapeHtml(imageSrc)}" alt="" style="max-width:140px;border-radius:8px;margin-bottom:8px;display:block;">`;paragraphs.forEach(p=>{html+=`<div style="font-size:13px;color:var(--sub);margin-bottom:6px;white-space:pre-wrap;">${escapeHtml(p)}</div>`});if(quote)html+=`<div style="border-left:2px solid var(--text);padding-left:10px;font-style:italic;margin-top:8px;">${escapeHtml(quote)}</div>`;if(hasVideo)html+=`<div style="margin-top:10px;font-size:11px;color:var(--dim);"><i class="fa-solid fa-video"></i> Video attached</div>`;box.innerHTML=html}


function blogEnterEditMode(id, title, tag, contentText, quoteText, lang, dateTimeStr){
  blogEditingId = id;
  blogEditingOriginalDateTime = dateTimeStr;
  document.getElementById('blogFormTitle').textContent = 'Edit Post';
  document.getElementById('blogEditingFlag').classList.add('show');
  document.getElementById('blogEditingTitle').textContent = title;
  document.getElementById('blogPublishBtnText').textContent = 'Save Changes';
  document.getElementById('blogTitle').value = title;
  document.getElementById('blogTag').value = tag;
  document.getElementById('blogContent').value = contentText;
  document.getElementById('blogQuote').value = quoteText;
  blogSetLang(lang);
  blogUpdatePreview();
  switchBlogTab('write');
}
function blogCancelEdit(){
  blogEditingId = null; blogEditingOriginalDateTime = null;
  document.getElementById('blogFormTitle').textContent = 'New Post';
  document.getElementById('blogEditingFlag').classList.remove('show');
  document.getElementById('blogPublishBtnText').textContent = 'Publish';
  document.getElementById('blogTitle').value = '';
  document.getElementById('blogTag').value = '';
  document.getElementById('blogContent').value = '';
  document.getElementById('blogQuote').value = '';
  blogClearImage(); blogClearVideo();
  document.getElementById('blogVideoUrl').value = '';
  blogSetVideoMode('yt');
  blogSetLang('en');
  blogUpdatePreview();
}

function sanitizeFilename(name){ return name.replace(/[^\w.\-]+/g,'-').toLowerCase(); }

async function blogUploadPendingMedia(){let imagePath=blogExistingImagePath,videoPath=blogExistingVideoPath;if(blogSelectedImageFile){const b64=await readFileAsBase64(blogSelectedImageFile),fname=`uploads/${Date.now()}-photo.jpg`;await putBinaryFile(fname,b64,null,`Upload image: ${fname}`);imagePath=fname}if(blogVideoMode==='upload'&&blogSelectedVideoFile){if(blogSelectedVideoFile.size>20*1024*1024)throw new Error('Video must be 20MB or smaller.');const b64=await readFileAsBase64(blogSelectedVideoFile),fname=`uploads/${Date.now()}-${sanitizeFilename(blogSelectedVideoFile.name)}`;await putBinaryFile(fname,b64,null,`Upload video: ${blogSelectedVideoFile.name}`);videoPath=fname}else if(blogVideoMode==='yt')videoPath=null;return{imagePath,videoPath}}


async function blogSubmitPost(){
  if(blogEditingId) await blogUpdatePost(); else await blogPublishPost();
}

async function blogPublishPost(){
  const title = document.getElementById('blogTitle').value.trim();
  const tag = document.getElementById('blogTag').value.trim();
  const content = document.getElementById('blogContent').value.trim();
  const quote = document.getElementById('blogQuote').value.trim();
  if(!localStorage.getItem('gh_token')){ showAlert('blogPublishStatus','<i class="fa-solid fa-triangle-exclamation"></i> Connect in My Profile first','alert-bad'); return; }
  if(!title || !content){ showAlert('blogPublishStatus','<i class="fa-solid fa-triangle-exclamation"></i> Title and content required','alert-bad'); return; }
  const btn = document.getElementById('blogPublishBtn');
  btn.disabled = true;
  showAlert('blogPublishStatus','<i class="fa-solid fa-spinner fa-spin"></i> Publishing...','alert-load');
  try {
    const file = await getFile('blog.html');
    if(!file) throw new Error('blog.html not found');
    if(!file.content.includes(BLOG_INSERT_MARK)) throw new Error('Admin marker not found in blog.html');
    const { imagePath, videoPath } = await blogUploadPendingMedia();
    const videoUrlVal = blogVideoMode === 'yt' ? normalizeYoutubeUrl(document.getElementById('blogVideoUrl').value) : '';
    const newId = 'post-' + Date.now();
    const block = blogBuildArticleBlock(newId, title, tag, content, quote, blogCurrentLang, null, imagePath, videoPath, videoUrlVal);
    const updatedContent = file.content.replace(BLOG_INSERT_MARK, BLOG_INSERT_MARK + '\n\n' + block);
    await putFile('blog.html', updatedContent, file.sha, `Add blog post: ${title}`);
    showAlert('blogPublishStatus','<i class="fa-solid fa-circle-check"></i> Published!','alert-ok');
    blogCancelEdit();
    blogLoadPostsList();
  } catch(e){ showAlert('blogPublishStatus','<i class="fa-solid fa-circle-xmark"></i> ' + e.message,'alert-bad'); }
  finally { btn.disabled = false; }
}

async function blogUpdatePost(){
  const title = document.getElementById('blogTitle').value.trim();
  const tag = document.getElementById('blogTag').value.trim();
  const content = document.getElementById('blogContent').value.trim();
  const quote = document.getElementById('blogQuote').value.trim();
  if(!title || !content){ showAlert('blogPublishStatus','<i class="fa-solid fa-triangle-exclamation"></i> Title and content required','alert-bad'); return; }
  const btn = document.getElementById('blogPublishBtn');
  btn.disabled = true;
  showAlert('blogPublishStatus','<i class="fa-solid fa-spinner fa-spin"></i> Saving...','alert-load');
  try {
    const file = await getFile('blog.html');
    if(!file) throw new Error('blog.html not found');
    const startTag = `<!-- POST:${blogEditingId}:START -->`, endTag = `<!-- POST:${blogEditingId}:END -->`;
    const s = file.content.indexOf(startTag), e = file.content.indexOf(endTag);
    if(s === -1 || e === -1) throw new Error('Post not found');
    const { imagePath, videoPath } = await blogUploadPendingMedia();
    const videoUrlVal = blogVideoMode === 'yt' ? normalizeYoutubeUrl(document.getElementById('blogVideoUrl').value) : '';
    const newBlock = blogBuildArticleBlock(blogEditingId, title, tag, content, quote, blogCurrentLang, blogEditingOriginalDateTime, imagePath, videoPath, videoUrlVal).trim();
    const updatedContent = file.content.slice(0, s) + newBlock + file.content.slice(e + endTag.length);
    await putFile('blog.html', updatedContent, file.sha, `Update blog post: ${title}`);
    showAlert('blogPublishStatus','<i class="fa-solid fa-circle-check"></i> Saved!','alert-ok');
    blogCancelEdit();
    blogLoadPostsList();
  } catch(e){ showAlert('blogPublishStatus','<i class="fa-solid fa-circle-xmark"></i> ' + e.message,'alert-bad'); }
  finally { btn.disabled = false; }
}

let blogPendingDeleteId = null, blogPendingDeleteTitle = null, blogPendingDeleteIsPost = false;

async function blogStartEditPost(id){
  try {
    const file = await getFile('blog.html');
    if(!file) throw new Error('blog.html not found');
    const startTag = `<!-- POST:${id}:START -->`, endTag = `<!-- POST:${id}:END -->`;
    const s = file.content.indexOf(startTag), e = file.content.indexOf(endTag);
    if(s === -1 || e === -1) throw new Error('Post not found');
    const blockHtml = file.content.slice(s + startTag.length, e);
    const parser = new DOMParser();
    const doc = parser.parseFromString(`<div>${blockHtml}</div>`, 'text/html');
    const article = doc.querySelector('article');
    if(!article) throw new Error('Could not read this post');
    const h1 = article.querySelector('.article-h1, .article-h1-bn');
    const tagEl = article.querySelector('.article-tag');
    const dateEl = article.querySelector('.article-date');
    const quoteEl = article.querySelector('.article-quote p');
    const imgEl = article.querySelector('.article-image img');
    const videoEl = article.querySelector('.article-video video');
    const iframeEl = article.querySelector('.article-video iframe');
    const paragraphs = Array.from(article.querySelectorAll('.article-p')).map(p => p.textContent.trim());
    const lang = h1 && h1.classList.contains('article-h1-bn') ? 'bn' : 'en';

    blogClearImage(); blogClearVideo();
    document.getElementById('blogVideoUrl').value = '';
    blogSetVideoMode('yt');
    if(imgEl){
      blogExistingImagePath = imgEl.getAttribute('src');
      document.getElementById('blogImagePreviewImg').src = blogExistingImagePath;
      document.getElementById('blogImagePreviewWrap').style.display = 'flex';
    }
    if(videoEl){
      blogSetVideoMode('upload');
      blogExistingVideoPath = videoEl.getAttribute('src');
      document.getElementById('blogVideoFileName').textContent = '(existing video — choose a new file to replace)';
      document.getElementById('blogVideoPreviewWrap').style.display = 'flex';
    } else if(iframeEl){
      const src = iframeEl.getAttribute('src') || '';
      const idMatch = src.match(/embed\/([\w-]{11})/);
      if(idMatch) document.getElementById('blogVideoUrl').value = `https://youtube.com/watch?v=${idMatch[1]}`;
      blogSetVideoMode('yt');
    }

    blogEnterEditMode(id, h1 ? h1.textContent.trim() : '', tagEl ? tagEl.textContent.trim() : '', paragraphs.join('\n\n'), quoteEl ? quoteEl.textContent.trim() : '', lang, dateEl ? dateEl.textContent.trim() : null);
  } catch(e){ showErrorAlert('blogPublishStatus','Could not load post — '+e.message); }
}

function blogDeletePost(id, title){
  blogPendingDeleteId = id; blogPendingDeleteTitle = title; blogPendingDeleteIsPost = true;
  document.getElementById('deleteModalTitle').textContent = title;
  document.getElementById('deleteModal').classList.add('show');
}

async function blogLoadPostsList(){
  const listEl = document.getElementById('blogPostsList');
  if(!localStorage.getItem('gh_token')){ listEl.innerHTML = '<div class="item-empty">Connect first.</div>'; return; }
  listEl.innerHTML = '<div class="item-empty"><i class="fa-solid fa-spinner fa-spin"></i> Loading...</div>';
  try {
    const file = await getFile('blog.html');
    if(!file) throw new Error('blog.html not found');
    const regex = /<!-- POST:([\w-]+):START -->([\s\S]*?)<!-- POST:\1:END -->/g;
    let match, html = '', count = 0;
    while((match = regex.exec(file.content)) !== null){
      const id = match[1];
      const parser = new DOMParser();
      const doc = parser.parseFromString(`<div>${match[2]}</div>`, 'text/html');
      const article = doc.querySelector('article');
      if(!article) continue;
      const h1 = article.querySelector('.article-h1, .article-h1-bn');
      const tagEl = article.querySelector('.article-tag');
      const dateEl = article.querySelector('.article-date');
      const titleText = h1 ? h1.textContent.trim() : '(untitled)';
      html += `<div class="item-row">
        <div class="item-row-head">
          <div class="item-row-title">${escapeHtml(titleText)}</div>
          <div class="item-row-actions">
            <button class="btn-icon" data-baction="edit" data-bid="${escapeHtml(id)}" title="Edit"><i class="fa-solid fa-pen"></i></button>
            <button class="btn-icon danger" data-baction="delete" data-bid="${escapeHtml(id)}" data-btitle="${escapeHtml(titleText)}" title="Delete"><i class="fa-solid fa-trash"></i></button>
          </div>
        </div>
        <div style="font-size:11.5px;color:var(--dim);">${tagEl ? escapeHtml(tagEl.textContent.trim()) : ''} · ${dateEl ? escapeHtml(dateEl.textContent.trim()) : ''}</div>
      </div>`;
      count++;
    }
    listEl.innerHTML = count ? html : '<div class="item-empty">No posts yet.</div>';
  } catch(e){ listEl.innerHTML = `<div class="item-empty" style="color:var(--bad);">${escapeHtml(e.message)}</div>`; }
}
document.getElementById('blogPostsList').addEventListener('click', function(e){
  const btn = e.target.closest('button[data-baction]');
  if(!btn) return;
  if(btn.dataset.baction === 'edit') blogStartEditPost(btn.dataset.bid);
  else if(btn.dataset.baction === 'delete') blogDeletePost(btn.dataset.bid, btn.dataset.btitle);
});

/* ══════════════════════════════════════
   SHARED DELETE MODAL (handles Blog posts)
══════════════════════════════════════ */
function closeDeleteModal(){
  document.getElementById('deleteModal').classList.remove('show');
  blogPendingDeleteId = null; blogPendingDeleteTitle = null; blogPendingDeleteIsPost = false;
}
document.getElementById('confirmDeleteBtn').addEventListener('click', async function(){
  if(!blogPendingDeleteIsPost) { closeDeleteModal(); return; }
  const id = blogPendingDeleteId, title = blogPendingDeleteTitle;
  const btn = this;
  btn.disabled = true; btn.innerHTML = '<i class="fa-solid fa-spinner fa-spin"></i>';
  try {
    const file = await getFile('blog.html');
    if(!file) throw new Error('blog.html not found');
    const startTag = `<!-- POST:${id}:START -->`, endTag = `<!-- POST:${id}:END -->`;
    const s = file.content.indexOf(startTag), e = file.content.indexOf(endTag);
    if(s === -1 || e === -1) throw new Error('Post not found');
    const updatedContent = file.content.slice(0, s) + file.content.slice(e + endTag.length);
    await putFile('blog.html', updatedContent, file.sha, `Delete blog post: ${title}`);
    if(blogEditingId === id) blogCancelEdit();
    closeDeleteModal();
    blogLoadPostsList();
  } catch(e){ showErrorAlert('blogPublishStatus','Could not delete — '+e.message); }
  finally { btn.disabled = false; btn.innerHTML = 'Delete'; }
});document.addEventListener('keydown',e=>{if(e.key==='Escape'){if(document.getElementById('siteModal').classList.contains('show'))closeSiteModal();else if(document.getElementById('deleteModal').classList.contains('show'))closeDeleteModal();else if(document.getElementById('drawer').classList.contains('open'))closeDrawer()}});
['deleteModal','siteModal'].forEach(id=>{const el=document.getElementById(id);el.addEventListener('click',e=>{if(e.target===el){id==='deleteModal'?closeDeleteModal():closeSiteModal()}})});

